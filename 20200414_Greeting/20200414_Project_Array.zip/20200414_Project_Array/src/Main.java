public class Main {

    public static void main(String[] args) {

        int[] numbers = new int[20];
        fillArray(numbers);
        printArray(numbers);
        System.out.println();
        /*int evenNumber = evenCount(numbers);
        System.out.println(evenNumber);*/
        System.out.println(evenCount(numbers));



    }
    public static void fillArray(int[] numbers){
        for (int i = 0; i <numbers.length ; i++) {
            numbers[i] = (int) (10 + Math.random() * (50 - 10 + 1));
        }

    }

   /* public static void fillArray2(int[] numbers){
        int i=0;
        for (int num:numbers) {
            num = (int) (10 + Math.random() * (50 - 10 + 1));
            numbers[i++] = num;
        }
    }*/

   public static void printArray(int[] numbers){
       for (int num:numbers) {
           System.out.print(num + " ");
       }
   }

   public static int evenCount(int[] numbers){
       int count =0;
       for(int num:numbers){
           if(num%2==0)
               count++;
       }
       return count;
   }

   public static int oddCount(int[] numbers){
       return numbers.length - evenCount(numbers);
   }

   
}
